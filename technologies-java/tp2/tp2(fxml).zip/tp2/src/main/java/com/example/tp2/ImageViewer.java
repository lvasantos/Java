package com.example.tp2;

import java.io.File;
import java.io.Serializable;
import java.util.Arrays;

import javafx.beans.property.BooleanProperty;
import javafx.beans.property.IntegerProperty;
import javafx.beans.property.SimpleBooleanProperty;
import javafx.beans.property.SimpleIntegerProperty;
import javafx.beans.property.SimpleStringProperty;
import javafx.beans.property.StringProperty;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;

public class ImageViewer extends ImageView implements Serializable {
    private static final long serialVersionUID = 1L;
    private final StringProperty directory = new SimpleStringProperty();
    private final IntegerProperty imageCount = new SimpleIntegerProperty();
    private final BooleanProperty loopMode = new SimpleBooleanProperty();

    private File[] images;
    private int currentIndex = 0;

//  No arg
  public ImageViewer() {
        directory.addListener((obs, oldDir, newDir) -> loadImages(newDir));
    }

    public String getDirectory() {
        return directory.get();
    }

    public void setDirectory(String dir) {
        this.directory.set(dir);
    }

    public StringProperty directoryProperty() {
        return directory;
    }

    public int getCurrentIndex() {
        return currentIndex;
    }

    // Getter e Setter para imageCount
    public int getImageCount() {
        return imageCount.get();
    }

    public void setImageCount(int count) {
        this.imageCount.set(count);
    }

    public IntegerProperty imageCountProperty() {
        return imageCount;
    }

    // Getter e Setter para loopMode
    public boolean isLoopMode() {
        return loopMode.get();
    }

    public void setLoopMode(boolean loop) {
        this.loopMode.set(loop);
    }

    public BooleanProperty loopModeProperty() {
        return loopMode;
    }

    private void loadImages(String dirPath) {
        File dir = new File(dirPath);
        if (dir.exists() && dir.isDirectory()) {
            images = dir.listFiles((d, name) -> name.toLowerCase().endsWith(".jpg") || name.toLowerCase().endsWith(".png"));
            if (images != null) {
                Arrays.sort(images);
                imageCount.set(images.length);
                if (images.length > 0) {
                    setImage(new Image(images[0].toURI().toString()));
                }
            }
        }
    }

    public void resetIndex() {
        currentIndex = 0;
    }


    public void showFirstImage() {
        if (images != null && images.length > 0) {
            currentIndex = 0;
            setImage(new Image(images[currentIndex].toURI().toString()));
        }
    }

    public void showLastImage() {
        if (images != null && images.length > 0) {
            currentIndex = images.length - 1;
            setImage(new Image(images[currentIndex].toURI().toString()));
        }
    }

public void showNextImage() {
    if (images != null && images.length > 0) {
        if (currentIndex < images.length - 1) {
            currentIndex++;
        } else if (loopMode.get()) { // Restart at the beginning
            currentIndex = 0;
        } else {
            return; // Stop at the last image
        }
        setImage(new Image(images[currentIndex].toURI().toString()));
    }
}

    public void showPreviousImage() {
        if (images != null && images.length > 0) {
            if (currentIndex > 0) {
                currentIndex--;
            } else if (loopMode.get()) { // Go back to last image
                currentIndex = images.length - 1;
            } else {
                return;
            }
            setImage(new Image(images[currentIndex].toURI().toString()));
        }
    }
}
